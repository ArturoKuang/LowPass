//export controllers to be used router
module.exports.Account = require('./Account.js');
module.exports.Profile = require('./Profile.js');
module.exports.Images = require('./Images.js');
